package vn.edu.fpt.farmservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FarmServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
